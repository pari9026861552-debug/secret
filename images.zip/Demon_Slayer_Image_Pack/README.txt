DEMON SLAYER CHARACTER IMAGE PACK — DOWNLOAD HELPER

This ZIP contains a downloader for the 20 character image filenames referenced by your website's character theme code.

HOW TO USE (Windows):
1. Extract this ZIP.
2. Open the extracted folder.
3. Double-click Download_Images.bat.
4. Keep your internet connection on. The script will create an "images" folder and download each available image from the official Demon Slayer Infinity Castle website.
5. Any filenames the official server does not provide will be listed in images\not-downloaded.txt.

IMPORTANT:
- This helper does not contain the image files themselves. The current file-creation environment could not fetch the official image server, so I cannot honestly package downloaded originals here.
- Image availability depends on the official server and the filenames used by the website code. Some files may not exist or may later move.
- These are copyrighted Demon Slayer character images. Follow the rights holder's terms for use and sharing.
