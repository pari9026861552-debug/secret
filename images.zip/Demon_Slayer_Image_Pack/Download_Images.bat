@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Download_Character_Images.ps1"
