$ErrorActionPreference = 'Continue'
$base = 'https://demonslayer-anime.com/infinitycastle/assets_1st/img/chara/'
$files = @(
'img_chara_tanjiro.jpg',
'img_chara_nezuko.jpg',
'img_chara_zennitsu.jpg',
'img_chara_inosuke.jpg',
'img_chara_kanowo.jpg',
'img_chara_gennya.jpg',
'img_chara_giyu.jpg',
'img_chara_muichiro.jpg',
'img_chara_shinobu.jpg',
'img_chara_mitsuri.jpg',
'img_chara_iguro.jpg',
'img_chara_sanemi.jpg',
'img_chara_himejima.jpg',
'img_chara_tengen.jpg',
'img_chara_muzan.jpg',
'img_chara_kokushibo.jpg',
'img_chara_douma.jpg',
'img_chara_akaza.jpg',
'img_chara_nakime.jpg',
'img_chara_kaigaku.jpg'
)
$out = Join-Path $PSScriptRoot 'images'
New-Item -ItemType Directory -Force -Path $out | Out-Null
$ok = 0; $failed = @()
foreach ($file in $files) {
  $url = $base + $file
  $dest = Join-Path $out $file
  try {
    Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing -TimeoutSec 25
    if ((Get-Item $dest).Length -gt 1000) { Write-Host "Downloaded: $file" -ForegroundColor Green; $ok++ }
    else { Remove-Item $dest -ErrorAction SilentlyContinue; $failed += $file; Write-Host "Failed/empty: $file" -ForegroundColor Yellow }
  } catch { Remove-Item $dest -ErrorAction SilentlyContinue; $failed += $file; Write-Host "Unavailable: $file" -ForegroundColor Yellow }
}
Write-Host "`nFinished: $ok downloaded; $($failed.Count) unavailable." -ForegroundColor Cyan
if ($failed.Count -gt 0) { $failed | Set-Content (Join-Path $out 'not-downloaded.txt') }
Write-Host "Images folder: $out"
Read-Host 'Press Enter to close'
